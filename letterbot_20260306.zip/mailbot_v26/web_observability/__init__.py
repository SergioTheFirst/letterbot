"""Web observability console package."""
